# Water Sort Puzzle (Android)

A simple portrait Android water-sort puzzle game. Tap a tube, then tap another tube to pour matching top colors. The **NEW GAME** button resets the puzzle.

## Build APK on GitHub

1. Upload all files and folders in this project to the root of a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow** (or push to `main`).
4. When the run finishes, open it and download the **WaterSortPuzzle-APK** artifact.
5. Extract the downloaded ZIP to get `app-debug.apk`.

This is a starter game project. The APK is a debug build for testing, not a Play Store release.
