package com.example.watersort

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(GameView())
    }

    inner class GameView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val colors = listOf(
            0xFFE94F64.toInt(), 0xFF35B7D3.toInt(),
            0xFFFFC247.toInt(), 0xFF8C6CE8.toInt()
        )
        private val tubes = mutableListOf(
            mutableListOf(0, 1, 2, 3),
            mutableListOf(1, 3, 0, 2),
            mutableListOf(2, 0, 3, 1),
            mutableListOf(3, 2, 1, 0),
            mutableListOf(), mutableListOf()
        )
        private var selected = -1
        private var moves = 0
        private var won = false
        private val tubeRects = mutableListOf<RectF>()

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawColor(0xFFF3F6FC.toInt())
            paint.color = 0xFF17233D.toInt()
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = width * 0.075f
            paint.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            canvas.drawText("WATER SORT", width / 2f, height * 0.12f, paint)

            paint.textSize = width * 0.038f
            paint.typeface = android.graphics.Typeface.create("sans-serif", 0)
            canvas.drawText("Moves: $moves     Tap a tube to pour", width / 2f, height * 0.17f, paint)

            tubeRects.clear()
            val tubeW = min(width * 0.15f, 92f)
            val tubeH = min(height * 0.27f, 220f)
            val gap = width * 0.055f
            val totalW = tubeW * 3 + gap * 2
            val startX = (width - totalW) / 2f
            val startY = height * 0.30f

            tubes.forEachIndexed { index, tube ->
                val row = index / 3
                val col = index % 3
                val x = startX + col * (tubeW + gap)
                val y = startY + row * (tubeH + height * 0.09f)
                val rect = RectF(x, y, x + tubeW, y + tubeH)
                tubeRects.add(rect)

                // Glass outline
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 5f
                paint.color = if (selected == index) 0xFF315FEA.toInt() else 0xFF8291A8.toInt()
                canvas.drawRoundRect(rect, 18f, 18f, paint)

                // Water layers, drawn as rounded liquid bands with a curved top surface
                val inner = RectF(x + 5, y + 5, x + tubeW - 5, y + tubeH - 5)
                val layerH = inner.height() / 4f
                tube.forEachIndexed { layer, colorIndex ->
                    val bottom = inner.bottom - layer * layerH
                    val top = bottom - layerH
                    paint.style = Paint.Style.FILL
                    paint.color = colors[colorIndex]
                    val water = RectF(inner.left, top, inner.right, bottom + 2)
                    canvas.drawRoundRect(water, 9f, 9f, paint)
                    // subtle glossy highlight
                    paint.color = 0x55FFFFFF
                    canvas.drawRoundRect(
                        RectF(inner.left + 7, top + 4, inner.left + 12, bottom - 4),
                        4f, 4f, paint
                    )
                }
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.color = 0x66829AB8
                canvas.drawRoundRect(rect, 18f, 18f, paint)
            }

            paint.style = Paint.Style.FILL
            paint.color = 0xFF315FEA.toInt()
            val button = RectF(width * .27f, height * .84f, width * .73f, height * .92f)
            canvas.drawRoundRect(button, 24f, 24f, paint)
            paint.color = -1
            paint.textSize = width * .045f
            paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
            canvas.drawText("NEW GAME", width / 2f, height * .89f, paint)

            if (won) {
                paint.color = 0xFF16834A.toInt()
                paint.textSize = width * .055f
                canvas.drawText("Puzzle solved! Great job!", width / 2f, height * .76f, paint)
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP) return true
            val x = event.x
            val y = event.y
            if (y > height * .82f) {
                resetGame()
                return true
            }
            val tapped = tubeRects.indexOfFirst { it.contains(x, y) }
            if (tapped >= 0) handleTube(tapped)
            return true
        }

        private fun handleTube(index: Int) {
            if (selected == -1) {
                if (tubes[index].isNotEmpty()) selected = index
            } else if (selected == index) {
                selected = -1
            } else {
                val from = tubes[selected]
                val to = tubes[index]
                if (from.isNotEmpty() && to.size < 4 &&
                    (to.isEmpty() || to.last() == from.last())) {
                    val color = from.last()
                    while (from.isNotEmpty() && from.last() == color && to.size < 4) {
                        to.add(from.removeAt(from.lastIndex))
                    }
                    moves++
                }
                selected = -1
                won = tubes.all { it.isEmpty() || (it.size == 4 && it.all { c -> c == it.first() }) }
                if (won) Toast.makeText(this, "You solved it!", Toast.LENGTH_SHORT).show()
            }
            invalidate()
        }

        private fun resetGame() {
            val fresh = listOf(
                listOf(0, 1, 2, 3), listOf(1, 3, 0, 2),
                listOf(2, 0, 3, 1), listOf(3, 2, 1, 0),
                emptyList(), emptyList()
            )
            tubes.clear()
            fresh.forEach { tubes.add(it.toMutableList()) }
            selected = -1
            moves = 0
            won = false
            invalidate()
        }
    }
}
